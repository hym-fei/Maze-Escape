# Maze Escape Game 🎮

This is a randomly generated maze escape game written in **Java** using `Swing` for GUI.

## Features

- 🧱 Random maze generation every time you start
- 🚶‍♂️ Player movement with arrow keys
- ⏱️ Countdown timer (60s per run)
- 🧠 Visited tiles visualization (green shade)
- 🎯 Escape the maze to win + earn score
- 💾 Easy to compile, play and modify

## How to Run

1. Compile the code:
    ```bash
    javac MazeEscapeGame.java
    ```

2. Run the game:
    ```bash
    java MazeEscapeGame
    ```

## Controls

- Arrow keys to move
- Reach the green tile `E` to escape
- Blue circle represents the player

## Screenshot

![screenshot](screenshot.png) *(you can add your screenshot)*

## Author

This project is entirely original and created by [Your Name Here].

Feel free to fork, modify, and explore more features like:
- Monsters, traps
- Path-finding animation
- Multiplayer mode
