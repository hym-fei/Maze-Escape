import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.sound.sampled.*;

public class MazeEscapeGame extends JFrame implements KeyListener {
    private static final int WIDTH = 600;
    private static final int HEIGHT = 600;
    private static final int TILE_SIZE = 60;
    private static final int MAZE_WIDTH = 10;
    private static final int MAZE_HEIGHT = 10;
    private static final String SAVE_FILE = "savegame.dat";

    private char[][] maze;
    private int currentLevel = 0;
    private int playerX = 1, playerY = 1;
    private boolean gameRunning = true;
    private int timeLeft = 60;
    private int score = 0;
    private GamePanel gamePanel;
    private Clip clip;
    private Set<String> visitedTiles = new HashSet<>();

    public MazeEscapeGame() {
        setTitle("Maze Escape Game");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        generateRandomMaze();

        gamePanel = new GamePanel();
        add(gamePanel, BorderLayout.CENTER);

        addKeyListener(this);
        setFocusable(true);
        requestFocusInWindow();

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if (gameRunning) {
                    timeLeft--;
                    gamePanel.repaint();
                    if (timeLeft <= 0) {
                        gameRunning = false;
                        JOptionPane.showMessageDialog(null, "Time's up! Game Over.");
                    }
                }
            }
        }, 1000, 1000);

        setVisible(true);
    }

    private void generateRandomMaze() {
        maze = new char[MAZE_HEIGHT][MAZE_WIDTH];
        for (int y = 0; y < MAZE_HEIGHT; y++) {
            for (int x = 0; x < MAZE_WIDTH; x++) {
                maze[y][x] = (Math.random() < 0.25 || x == 0 || y == 0 || x == MAZE_WIDTH - 1 || y == MAZE_HEIGHT - 1) ? '#' : ' ';
            }
        }
        playerX = 1;
        playerY = 1;
        maze[playerY][playerX] = 'P';
        maze[MAZE_HEIGHT - 2][MAZE_WIDTH - 2] = 'E';
    }

    class GamePanel extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            for (int y = 0; y < maze.length; y++) {
                for (int x = 0; x < maze[y].length; x++) {
                    char tile = maze[y][x];
                    String key = x + "," + y;
                    if (visitedTiles.contains(key)) {
                        g.setColor(new Color(220, 255, 220));
                    } else {
                        switch (tile) {
                            case '#':
                                g.setColor(Color.BLACK);
                                break;
                            case ' ':
                                g.setColor(Color.WHITE);
                                break;
                            case 'P':
                                g.setColor(Color.WHITE);
                                g.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                                g.setColor(Color.BLUE);
                                g.fillOval(x * TILE_SIZE + 10, y * TILE_SIZE + 10, TILE_SIZE - 20, TILE_SIZE - 20);
                                continue;
                            case 'E':
                                g.setColor(Color.GREEN);
                                break;
                            default:
                                g.setColor(Color.WHITE);
                                break;
                        }
                    }
                    g.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                    g.setColor(Color.GRAY);
                    g.drawRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                }
            }
            g.setColor(Color.RED);
            g.drawString("Time Left: " + timeLeft + "s    Score: " + score, 10, 15);
        }
    }

    public void keyPressed(KeyEvent e) {
        if (!gameRunning) return;

        int dx = 0, dy = 0;
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP: dy = -1; break;
            case KeyEvent.VK_DOWN: dy = 1; break;
            case KeyEvent.VK_LEFT: dx = -1; break;
            case KeyEvent.VK_RIGHT: dx = 1; break;
            default: return;
        }

        int newX = playerX + dx;
        int newY = playerY + dy;

        if (newY >= 0 && newY < maze.length && newX >= 0 && newX < maze[0].length && maze[newY][newX] != '#') {
            maze[playerY][playerX] = ' ';
            visitedTiles.add(playerX + "," + playerY);
            playerX = newX;
            playerY = newY;

            if (maze[playerY][playerX] == 'E') {
                score += 100;
                gameRunning = false;
                gamePanel.repaint();
                JOptionPane.showMessageDialog(null, "You reached the exit!\nScore: " + score);
                return;
            } else {
                maze[playerY][playerX] = 'P';
            }
            gamePanel.repaint();
        }
    }

    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MazeEscapeGame game = new MazeEscapeGame();
            game.requestFocus();
        });
    }
}